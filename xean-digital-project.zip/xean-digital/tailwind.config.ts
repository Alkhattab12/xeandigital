import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './lib/**/*.{js,ts,jsx,tsx,mdx}'
  ],
  theme: {
    extend: {
      colors: {
        background: '#07111f',
        foreground: '#f4f7fb',
        muted: '#98a4b9',
        border: 'rgba(255,255,255,0.12)',
        card: 'rgba(255,255,255,0.06)',
        brand: {
          50: '#eef4ff',
          100: '#dde8ff',
          200: '#bfd2ff',
          300: '#8fb2ff',
          400: '#5d8fff',
          500: '#356df7',
          600: '#2455d5',
          700: '#1f46ad',
          800: '#203f88',
          900: '#1f356d'
        },
        accent: {
          cyan: '#7CE6FF',
          purple: '#9F7CFF',
          pink: '#FF8FE8'
        }
      },
      boxShadow: {
        glow: '0 20px 70px rgba(53,109,247,0.25)',
        card: '0 18px 50px rgba(7, 17, 31, 0.45)'
      },
      backgroundImage: {
        'radial-orb': 'radial-gradient(circle at center, rgba(124,230,255,0.18), transparent 58%)',
        'brand-mesh': 'radial-gradient(circle at 20% 20%, rgba(124,230,255,0.15), transparent 25%), radial-gradient(circle at 80% 0%, rgba(159,124,255,0.18), transparent 30%), radial-gradient(circle at 80% 80%, rgba(255,143,232,0.14), transparent 25%), linear-gradient(180deg, rgba(9,14,25,1) 0%, rgba(5,11,22,1) 100%)'
      },
      animation: {
        float: 'float 10s ease-in-out infinite',
        pulseSlow: 'pulseSlow 12s ease-in-out infinite',
        shine: 'shine 3.2s linear infinite'
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-16px)' }
        },
        pulseSlow: {
          '0%, 100%': { transform: 'scale(1)', opacity: '0.8' },
          '50%': { transform: 'scale(1.08)', opacity: '1' }
        },
        shine: {
          '0%': { transform: 'translateX(-120%)' },
          '100%': { transform: 'translateX(220%)' }
        }
      }
    }
  },
  plugins: []
};

export default config;
