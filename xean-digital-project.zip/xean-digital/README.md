# Xean Digital — Production-Ready Multi-Page Website

Website multi-halaman untuk brand **Xean Digital** dengan gaya premium, abstrak, futuristik, namun tetap profesional dan mudah dipahami.

Stack utama:
- **Next.js** (App Router)
- **Tailwind CSS**
- **Framer Motion**
- **Firebase Authentication** (Google + Nomor Telepon OTP)
- **Firebase Admin** (session cookie server-side)
- **Firestore** (opsional, untuk sinkronisasi profil dasar)

---

## Ringkasan konsep

Xean Digital diposisikan sebagai brand creative-tech premium. Website ini dirancang untuk:
- menjelaskan siapa Xean Digital secara cepat di halaman awal,
- menampilkan katalog layanan yang benar-benar jelas,
- membawa user ke alur daftar/login yang real,
- memberi kesan aesthetic, interaktif, modern, dan terpercaya,
- tetap rapi secara struktur agar tidak terasa seperti template landing page biasa.

Visual memakai kombinasi:
- dark premium backdrop,
- abstract gradient glow,
- glassmorphism ringan,
- micro-interaction,
- hover elevation,
- page transition halus,
- scroll reveal animation.

---

## Sitemap

- `/` → **Home**
- `/tentang-kami` → **Tentang Kami**
- `/layanan` → **Layanan**
- `/daftar` → **Daftar**
- `/login` → **Login**
- `/dashboard` → **Dashboard (protected)**

---

## User flow

### 1) Visitor browsing flow
Home → Tentang Kami / Layanan → CTA → Daftar atau Login

### 2) Registrasi flow
Daftar → pilih **Google** atau **Nomor Telepon** → autentikasi Firebase → session cookie dibuat → redirect ke Dashboard

### 3) Login flow
Login → pilih **Google** atau **Nomor Telepon** → autentikasi Firebase → session cookie dibuat → redirect ke Dashboard

### 4) Dashboard flow
Dashboard → lihat identitas user → logout → sesi server + sesi client dihapus

---

## Struktur folder

```bash
xean-digital/
├── app/
│   ├── api/
│   │   └── auth/
│   │       └── session/
│   │           └── route.ts
│   ├── daftar/
│   │   └── page.tsx
│   ├── dashboard/
│   │   ├── loading.tsx
│   │   └── page.tsx
│   ├── layanan/
│   │   └── page.tsx
│   ├── login/
│   │   └── page.tsx
│   ├── tentang-kami/
│   │   └── page.tsx
│   ├── globals.css
│   ├── layout.tsx
│   ├── not-found.tsx
│   ├── page.tsx
│   ├── robots.ts
│   ├── sitemap.ts
│   └── template.tsx
├── components/
│   ├── auth/
│   ├── layout/
│   ├── providers/
│   ├── sections/
│   └── ui/
├── firebase/
│   └── firestore.rules
├── lib/
│   ├── auth/
│   ├── config/
│   ├── data/
│   └── firebase/
├── .env.example
├── next.config.ts
├── package.json
├── server.js
├── tailwind.config.ts
└── README.md
```

---

## Fitur utama

### Desain & UX
- Multi-page architecture, bukan one-page panjang
- Hero yang hidup dan engaging
- Gradient abstrak + glass surface
- Hover effects, scroll reveal, page transition
- Mobile-friendly, tablet-friendly, desktop-friendly

### Auth nyata
- **Google Sign-In** via Firebase Authentication
- **Phone Sign-In** via OTP Firebase Authentication
- **Tanpa email-password biasa**
- Session cookie server-side via Firebase Admin
- Dashboard hanya bisa dibuka jika sesi valid

### SEO & struktur
- Metadata dasar
- `sitemap.ts`
- `robots.ts`
- Struktur komponen reusable

---

## Setup lokal

### 1. Install dependency
```bash
npm install
```

### 2. Copy env
```bash
cp .env.example .env.local
```

### 3. Isi environment Firebase
Lengkapi `.env.local` dengan nilai dari Firebase project Anda.

Minimal yang wajib untuk client:
- `NEXT_PUBLIC_FIREBASE_API_KEY`
- `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN`
- `NEXT_PUBLIC_FIREBASE_PROJECT_ID`
- `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET`
- `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID`
- `NEXT_PUBLIC_FIREBASE_APP_ID`

Untuk session server-side:
- `FIREBASE_PROJECT_ID`
- `FIREBASE_CLIENT_EMAIL`
- `FIREBASE_PRIVATE_KEY`

Opsional namun disarankan:
- `NEXT_PUBLIC_SITE_URL`
- `NEXT_PUBLIC_WHATSAPP_NUMBER`

### 4. Jalankan development server
```bash
npm run dev
```

Akses di:
```bash
http://localhost:3000
```

---

## Setup Firebase yang wajib

### Authentication
Aktifkan provider berikut di Firebase Console:
- **Google**
- **Phone**

### Authorized domain
Tambahkan domain produksi:
- `xeandigital.my.id`
- `www.xeandigital.my.id` (jika dipakai)

### Firestore
Buat database Firestore jika ingin menyimpan profil dasar user. Bila Firestore belum dibuat, login tetap bisa berjalan, tetapi sinkronisasi profil ke database akan dilewati.

### Firestore Rules
Gunakan file berikut sebagai referensi:
- `firebase/firestore.rules`

---

## Nomor WhatsApp CTA

Nomor WhatsApp CTA saat ini membaca dari:
```env
NEXT_PUBLIC_WHATSAPP_NUMBER=6281234567890
```

Ganti dengan nomor aktif brand Xean Digital.

---

## Akun test untuk Phone Auth

Untuk development, sangat disarankan memakai **fictional phone numbers** di Firebase Console agar tidak terkena limit SMS nyata.

---

## Deploy ke hosting / domain xeandigital.my.id

Ada dua jalur yang cocok:

### Opsi A — Shared Hosting / Hosting dengan Setup NodeJS App (Domainesia)
Paling cocok jika paket hosting Anda mendukung Node.js.

#### Langkah umum
1. Upload source project ke hosting
2. Masuk ke **cPanel**
3. Buka menu **Setup NodeJS App**
4. Pilih versi Node.js yang kompatibel
5. Set application root ke folder project
6. Set startup file ke:
```bash
server.js
```
7. Masuk terminal hosting / SSH
8. Jalankan:
```bash
npm install
npm run build
```
9. Restart Node.js App dari panel
10. Arahkan domain `xeandigital.my.id` ke app tersebut

#### Environment variables
Tambahkan semua env Firebase di panel / `.env.local` hosting.

#### Catatan
- Pastikan hosting Anda mendukung **Node.js runtime**, bukan hanya PHP static hosting.
- Jika memakai subdomain dulu untuk testing, tambahkan domain itu ke Firebase Authorized Domains.

### Opsi B — VPS Domainesia
Lebih fleksibel dan paling stabil untuk skala lanjut.

#### Langkah umum
1. Install Node.js LTS
2. Upload / clone project
3. Set `.env.local`
4. Jalankan:
```bash
npm install
npm run build
npm run start
```
5. Jalankan dengan **PM2** agar tetap aktif
6. Reverse proxy lewat Nginx ke port aplikasi
7. Pasang SSL untuk `xeandigital.my.id`

Contoh PM2:
```bash
npm install -g pm2
pm2 start npm --name xean-digital -- start
pm2 save
pm2 startup
```

---

## Checklist produksi sebelum live

- [ ] Google provider aktif di Firebase
- [ ] Phone provider aktif di Firebase
- [ ] Authorized domain Firebase sudah ditambahkan
- [ ] Env Firebase client dan admin lengkap
- [ ] `NEXT_PUBLIC_WHATSAPP_NUMBER` diganti ke nomor brand asli
- [ ] Domain `xeandigital.my.id` sudah diarahkan ke hosting
- [ ] SSL aktif
- [ ] Build produksi berhasil
- [ ] Dashboard bisa diakses hanya setelah login

---

## Pengembangan lanjutan yang direkomendasikan

Tahap berikut yang sangat cocok ditambahkan:
- order management
- invoice / payment status
- histori layanan user
- paket membership
- panel admin internal
- role-based access
- integrasi database order
- tracking lead & conversion

---

## Catatan penting

Project ini sudah disusun agar **auth benar-benar nyata** dan **dashboard benar-benar protected** melalui session cookie server-side. Namun agar berjalan penuh di produksi, Anda tetap perlu:
- membuat Firebase project,
- mengaktifkan provider Auth,
- mengisi env,
- dan memastikan hosting Node.js aktif.

Setelah itu, website ini siap dipakai sebagai pondasi brand **Xean Digital** di domain **xeandigital.my.id**.
