import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function toE164Indonesia(phone: string) {
  const normalized = phone.replace(/[^\d+]/g, '');

  if (/^\+62\d{8,13}$/.test(normalized)) return normalized;
  if (/^62\d{8,13}$/.test(normalized)) return `+${normalized}`;
  if (/^08\d{8,12}$/.test(normalized)) return `+62${normalized.slice(1)}`;

  return null;
}

export function formatPhoneDisplay(phone?: string | null) {
  if (!phone) return '—';
  return phone;
}

export function formatAuthError(error: unknown) {
  const message = typeof error === 'object' && error && 'message' in error ? String(error.message) : 'Terjadi kesalahan.';

  if (message.includes('auth/popup-closed-by-user')) return 'Jendela login ditutup sebelum proses selesai.';
  if (message.includes('auth/popup-blocked')) return 'Popup login diblokir browser. Coba izinkan popup atau gunakan perangkat lain.';
  if (message.includes('auth/invalid-phone-number')) return 'Nomor telepon belum valid. Gunakan format Indonesia seperti 08xx atau +62xx.';
  if (message.includes('auth/too-many-requests')) return 'Terlalu banyak percobaan. Coba lagi beberapa saat lagi.';
  if (message.includes('auth/code-expired')) return 'Kode OTP sudah kedaluwarsa. Silakan kirim ulang.';
  if (message.includes('auth/invalid-verification-code')) return 'Kode OTP tidak valid. Periksa kembali kode yang Anda masukkan.';
  if (message.includes('auth/network-request-failed')) return 'Koneksi bermasalah. Periksa internet Anda lalu coba lagi.';
  if (message.includes('auth/captcha-check-failed')) return 'Verifikasi keamanan gagal. Silakan muat ulang halaman lalu coba lagi.';
  if (message.includes('Firebase: Error (auth/operation-not-allowed)')) return 'Metode login ini belum diaktifkan di Firebase Console.';

  return message;
}
