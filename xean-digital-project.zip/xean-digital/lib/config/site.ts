export const siteConfig = {
  name: 'Xean Digital',
  shortName: 'Xean',
  description:
    'Brand digital premium yang merancang website, automasi, panel, bot, dan sistem kreatif untuk bisnis yang ingin tampil lebih modern, bergerak lebih cepat, dan tumbuh lebih presisi.',
  url: process.env.NEXT_PUBLIC_SITE_URL || 'https://xeandigital.my.id',
  domain: 'xeandigital.my.id',
  contactEmail: 'hello@xeandigital.my.id',
  whatsappNumber: process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || '6281234567890',
  nav: [
    { label: 'Home', href: '/' },
    { label: 'Tentang Kami', href: '/tentang-kami' },
    { label: 'Layanan', href: '/layanan' },
    { label: 'Daftar', href: '/daftar' },
    { label: 'Login', href: '/login' }
  ]
} as const;

export function createWhatsAppLink(message: string) {
  const text = encodeURIComponent(message);
  return `https://wa.me/${siteConfig.whatsappNumber}?text=${text}`;
}
