import 'server-only';

import { cookies } from 'next/headers';

import { adminAuth, adminDb } from '@/lib/firebase/admin';

export const SESSION_COOKIE_NAME = '__session';

export async function getServerSession() {
  const cookieStore = await cookies();
  const sessionCookie = cookieStore.get(SESSION_COOKIE_NAME)?.value;

  if (!sessionCookie) return null;

  try {
    return await adminAuth().verifySessionCookie(sessionCookie, true);
  } catch {
    return null;
  }
}

export async function getServerUserProfile(uid: string) {
  try {
    const snapshot = await adminDb().collection('users').doc(uid).get();
    return snapshot.exists ? snapshot.data() : null;
  } catch {
    return null;
  }
}
