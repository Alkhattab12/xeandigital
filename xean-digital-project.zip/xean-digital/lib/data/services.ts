import { createWhatsAppLink } from '@/lib/config/site';

export type ServiceItem = {
  slug: string;
  title: string;
  short: string;
  description: string;
  category: string;
  highlight: string;
  bullets: string[];
  ctaLabel: string;
  whatsappMessage: string;
  price: string;
};

export const services: ServiceItem[] = [
  {
    slug: 'website-premium',
    title: 'Pembuatan Website Premium',
    short: 'Website modern, cepat, responsif, dan siap tampil profesional.',
    description:
      'Website company profile, landing multi-halaman, katalog jasa, dashboard internal, atau portal bisnis dengan desain premium dan performa tinggi.',
    category: 'Web Development',
    highlight: 'SEO-ready + scalable architecture',
    bullets: ['Next.js modern', 'Mobile-first', 'Animasi halus', 'Siap domain custom'],
    ctaLabel: 'Diskusikan Website',
    whatsappMessage:
      'Halo Xean Digital, saya tertarik dengan layanan Pembuatan Website Premium. Saya ingin konsultasi kebutuhan website saya.',
    price: 'Mulai Rp1.500.000'
  },
  {
    slug: 'panel-pterodactyl-1gb',
    title: 'Panel Pterodactyl 1GB',
    short: 'Panel ringan untuk kebutuhan bot, testing, atau project kecil.',
    description:
      'Paket panel Pterodactyl 1GB untuk kebutuhan operasional ringan, bot sederhana, atau eksperimen deployment yang efisien.',
    category: 'Hosting & Panel',
    highlight: 'Stabil untuk kebutuhan ringan',
    bullets: ['1GB RAM', 'Akses panel', 'Setup cepat', 'Cocok untuk pemula'],
    ctaLabel: 'Pesan Panel 1GB',
    whatsappMessage:
      'Halo Xean Digital, saya ingin pesan Panel Pterodactyl 1GB. Mohon info detail dan ketersediaannya.',
    price: 'Harga spesial via WhatsApp'
  },
  {
    slug: 'panel-pterodactyl-unlimited',
    title: 'Panel Pterodactyl Unlimited',
    short: 'Untuk kebutuhan lebih besar dengan ruang tumbuh yang fleksibel.',
    description:
      'Panel untuk kebutuhan operasional aktif, multi-bot, atau workload lebih tinggi dengan konfigurasi yang lebih lega dan scalable.',
    category: 'Hosting & Panel',
    highlight: 'Fleksibel untuk scaling',
    bullets: ['Resource besar', 'Cocok multi project', 'Pendampingan setup', 'Siap pakai'],
    ctaLabel: 'Pesan Panel Unlimited',
    whatsappMessage:
      'Halo Xean Digital, saya tertarik dengan Panel Pterodactyl Unlimited. Saya ingin lihat penawaran terbaiknya.',
    price: 'By request'
  },
  {
    slug: 'social-media-injection',
    title: 'Social Media Injection',
    short: 'Dorong awareness dan engagement dengan delivery yang lebih terukur.',
    description:
      'Solusi distribusi sosial media untuk membantu exposure brand atau campaign dengan alur pemesanan yang lebih rapi dan cepat.',
    category: 'Growth Support',
    highlight: 'Eksekusi cepat untuk campaign digital',
    bullets: ['Alur pemesanan cepat', 'Katalog rapi', 'Support campaign', 'Responsive handling'],
    ctaLabel: 'Pesan Social Media Injection',
    whatsappMessage:
      'Halo Xean Digital, saya ingin memesan layanan Social Media Injection. Mohon kirim detail katalog dan proses order.',
    price: 'Sesuai kebutuhan'
  },
  {
    slug: 'bot-whatsapp-custom',
    title: 'Bot WhatsApp Custom',
    short: 'Bot WA untuk otomasi reply, order, notifikasi, dan alur internal.',
    description:
      'Pembuatan bot WhatsApp custom untuk kebutuhan bisnis, komunitas, toko digital, auto-reply, menu order, reminder, dan integrasi workflow.',
    category: 'Automation',
    highlight: 'Terintegrasi dengan workflow Anda',
    bullets: ['Auto reply', 'Menu interaktif', 'Webhook/API ready', 'Custom fitur'],
    ctaLabel: 'Bangun Bot WhatsApp',
    whatsappMessage:
      'Halo Xean Digital, saya tertarik membuat Bot WhatsApp Custom. Saya ingin konsultasi fitur dan estimasi pengerjaan.',
    price: 'Mulai Rp850.000'
  },
  {
    slug: 'desain-web-ui',
    title: 'Desain Web & UI Experience',
    short: 'Desain antarmuka yang elegan, modern, dan terasa premium.',
    description:
      'Layanan desain UI/UX untuk website, dashboard, atau microsite dengan fokus pada brand perception, clarity, dan conversion.',
    category: 'Creative Design',
    highlight: 'Visual premium yang tidak terasa generik',
    bullets: ['UI system', 'Prototype modern', 'Responsive layout', 'Conversion-aware'],
    ctaLabel: 'Konsultasi Desain',
    whatsappMessage:
      'Halo Xean Digital, saya tertarik dengan layanan Desain Web & UI Experience. Bisa bantu konsultasi style dan scope project?',
    price: 'Mulai Rp650.000'
  },
  {
    slug: 'automasi-operasional',
    title: 'Automasi Operasional Digital',
    short: 'Otomasi alur kerja agar tim bergerak lebih cepat dan lebih rapi.',
    description:
      'Automasi untuk lead intake, notifikasi, sinkronisasi data, form, approval, hingga sistem internal sederhana yang mengurangi kerja manual.',
    category: 'Automation',
    highlight: 'Workflow lebih efisien, minim repetisi',
    bullets: ['Workflow mapping', 'Integrasi tools', 'Notifikasi otomatis', 'Monitoring dasar'],
    ctaLabel: 'Diskusikan Automasi',
    whatsappMessage:
      'Halo Xean Digital, saya ingin konsultasi layanan Automasi Operasional Digital untuk kebutuhan bisnis saya.',
    price: 'Scope custom'
  }
];

export const socialProof = [
  'Dipilih untuk project cepat dengan hasil yang tetap presisi.',
  'Desain terasa premium, namun alurnya tetap jelas untuk user akhir.',
  'Komunikasi enak, pengerjaan rapi, dan eksekusinya tidak bertele-tele.'
];

export const serviceCatalogLinks = services.map((item) => ({
  ...item,
  whatsappLink: createWhatsAppLink(item.whatsappMessage)
}));
