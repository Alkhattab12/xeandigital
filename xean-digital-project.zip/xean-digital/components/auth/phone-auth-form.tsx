'use client';

import { useEffect, useRef, useState } from 'react';
import type { ConfirmationResult, User } from 'firebase/auth';
import { RecaptchaVerifier, signInWithPhoneNumber } from 'firebase/auth';

import { Button } from '@/components/ui/button';
import { StatusBox } from '@/components/ui/status-box';
import { auth } from '@/lib/firebase/client';
import { formatAuthError, toE164Indonesia } from '@/lib/utils';

declare global {
  interface Window {
    recaptchaVerifier?: RecaptchaVerifier;
    recaptchaWidgetId?: number;
    grecaptcha?: { reset: (id?: number) => void };
  }
}

export function PhoneAuthForm({
  mode,
  onAuthenticated
}: {
  mode: 'register' | 'login';
  onAuthenticated: (user: User) => Promise<void>;
}) {
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [confirmation, setConfirmation] = useState<ConfirmationResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<{ type: 'error' | 'success' | 'info'; message: string } | null>(null);
  const verifierReady = useRef(false);

  useEffect(() => {
    if (verifierReady.current) return;

    verifierReady.current = true;

    const verifier = new RecaptchaVerifier(auth, 'phone-otp-button', {
      size: 'invisible',
      callback: () => undefined,
      'expired-callback': () => {
        setStatus({ type: 'info', message: 'Verifikasi keamanan kedaluwarsa. Coba kirim kode kembali.' });
      }
    });

    window.recaptchaVerifier = verifier;
    void verifier.render().then((widgetId) => {
      window.recaptchaWidgetId = widgetId;
    });

    return () => {
      verifier.clear();
    };
  }, []);

  async function sendCode() {
    const normalizedPhone = toE164Indonesia(phone);
    if (!normalizedPhone) {
      setStatus({ type: 'error', message: 'Gunakan nomor Indonesia yang valid, misalnya 0812xxxx atau +62812xxxx.' });
      return;
    }

    if (!window.recaptchaVerifier) {
      setStatus({ type: 'error', message: 'reCAPTCHA belum siap. Muat ulang halaman lalu coba lagi.' });
      return;
    }

    try {
      setLoading(true);
      setStatus({ type: 'info', message: 'Mengirim kode OTP ke nomor Anda...' });
      const result = await signInWithPhoneNumber(auth, normalizedPhone, window.recaptchaVerifier);
      setConfirmation(result);
      setStatus({ type: 'success', message: 'Kode OTP sudah dikirim. Cek SMS Anda lalu masukkan 6 digit kode.' });
    } catch (error) {
      window.grecaptcha?.reset(window.recaptchaWidgetId);
      setStatus({ type: 'error', message: formatAuthError(error) });
    } finally {
      setLoading(false);
    }
  }

  async function verifyCode() {
    if (!confirmation) return;

    try {
      setLoading(true);
      setStatus({ type: 'info', message: 'Memverifikasi kode OTP Anda...' });
      const result = await confirmation.confirm(otp);
      await onAuthenticated(result.user);
      setStatus({ type: 'success', message: mode === 'register' ? 'Registrasi berhasil. Mengarahkan ke dashboard...' : 'Login berhasil. Mengarahkan ke dashboard...' });
    } catch (error) {
      setStatus({ type: 'error', message: formatAuthError(error) });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-4">
      <div>
        <label className="mb-2 block text-sm font-medium text-white/84">Nomor telepon</label>
        <input
          className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-white outline-none transition focus:border-accent-cyan/40 focus:bg-white/8"
          placeholder="Contoh: 081234567890"
          value={phone}
          onChange={(event) => setPhone(event.target.value)}
          inputMode="tel"
        />
      </div>

      {confirmation ? (
        <div>
          <label className="mb-2 block text-sm font-medium text-white/84">Kode OTP</label>
          <input
            className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-white outline-none transition focus:border-accent-cyan/40 focus:bg-white/8"
            placeholder="Masukkan 6 digit kode"
            value={otp}
            onChange={(event) => setOtp(event.target.value.replace(/\D/g, '').slice(0, 6))}
            inputMode="numeric"
          />
        </div>
      ) : null}

      {status ? <StatusBox type={status.type} message={status.message} /> : null}

      {confirmation ? (
        <div className="grid gap-3 sm:grid-cols-2">
          <Button variant="secondary" size="lg" onClick={() => setConfirmation(null)} disabled={loading}>
            Ganti Nomor
          </Button>
          <Button size="lg" onClick={() => void verifyCode()} loading={loading} disabled={otp.length !== 6}>
            Verifikasi OTP
          </Button>
        </div>
      ) : (
        <Button id="phone-otp-button" size="lg" className="w-full" onClick={() => void sendCode()} loading={loading}>
          Kirim OTP
        </Button>
      )}

      <p className="text-xs leading-6 text-white/45">
        Dengan melanjutkan, Anda setuju menerima SMS verifikasi dari Firebase Authentication untuk proses autentikasi nomor telepon.
      </p>

      <div id="recaptcha-container" />
    </div>
  );
}
