'use client';

import { Chrome } from 'lucide-react';

import { Button } from '@/components/ui/button';

export function GoogleAuthButton({
  onClick,
  loading,
  label
}: {
  onClick: () => Promise<void> | void;
  loading?: boolean;
  label: string;
}) {
  return (
    <Button className="w-full justify-center" variant="secondary" size="lg" onClick={() => void onClick()} loading={loading}>
      <Chrome className="h-4 w-4" /> {label}
    </Button>
  );
}
