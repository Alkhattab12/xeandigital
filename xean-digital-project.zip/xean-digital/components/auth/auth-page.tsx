'use client';

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { getRedirectResult, GoogleAuthProvider, signInWithPopup, signInWithRedirect, type User } from 'firebase/auth';

import { GoogleAuthButton } from '@/components/auth/google-auth-button';
import { PhoneAuthForm } from '@/components/auth/phone-auth-form';
import { ButtonLink } from '@/components/ui/button';
import { StatusBox } from '@/components/ui/status-box';
import { auth } from '@/lib/firebase/client';
import { formatAuthError } from '@/lib/utils';

export function AuthPage({ mode }: { mode: 'register' | 'login' }) {
  const router = useRouter();
  const [loadingGoogle, setLoadingGoogle] = useState(false);
  const [status, setStatus] = useState<{ type: 'error' | 'success' | 'info'; message: string } | null>(null);
  const [finalizing, setFinalizing] = useState(false);

  const isRegister = mode === 'register';

  const copy = useMemo(
    () => ({
      heading: isRegister ? 'Buat akses ke ekosistem Xean Digital' : 'Masuk kembali ke workspace Xean Digital',
      paragraph: isRegister
        ? 'Daftar hanya dengan Google atau nomor telepon untuk mulai menggunakan layanan dan mengakses dashboard Anda.'
        : 'Login aman dengan Google atau OTP nomor telepon. Tidak ada email-password biasa di sini.',
      switchText: isRegister ? 'Sudah punya akses?' : 'Belum punya akun?',
      switchHref: isRegister ? '/login' : '/daftar',
      switchLabel: isRegister ? 'Login di sini' : 'Daftar sekarang',
      googleLabel: isRegister ? 'Daftar dengan Google' : 'Login dengan Google'
    }),
    [isRegister]
  );

  useEffect(() => {
    void (async () => {
      try {
        const result = await getRedirectResult(auth);
        if (result?.user) {
          await finalizeAuth(result.user);
        }
      } catch (error) {
        setStatus({ type: 'error', message: formatAuthError(error) });
      }
    })();
  }, []);

  async function finalizeAuth(user: User) {
    try {
      setFinalizing(true);
      setStatus({ type: 'info', message: 'Menyinkronkan sesi aman Anda...' });
      const idToken = await user.getIdToken(true);
      const response = await fetch('/api/auth/session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken })
      });

      if (!response.ok) {
        const payload = (await response.json().catch(() => null)) as { message?: string } | null;
        throw new Error(payload?.message || 'Gagal membuat sesi login.');
      }

      setStatus({
        type: 'success',
        message: isRegister ? 'Akun berhasil dibuat. Mengarahkan Anda ke dashboard...' : 'Login berhasil. Mengarahkan Anda ke dashboard...'
      });

      router.push('/dashboard');
      router.refresh();
    } catch (error) {
      setStatus({ type: 'error', message: formatAuthError(error) });
    } finally {
      setFinalizing(false);
    }
  }

  async function handleGoogleAuth() {
    try {
      setLoadingGoogle(true);
      setStatus({ type: 'info', message: 'Membuka autentikasi Google...' });
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });

      const isSmallScreen = typeof window !== 'undefined' && window.matchMedia('(max-width: 768px)').matches;

      if (isSmallScreen) {
        await signInWithRedirect(auth, provider);
        return;
      }

      const result = await signInWithPopup(auth, provider);
      await finalizeAuth(result.user);
    } catch (error) {
      setStatus({ type: 'error', message: formatAuthError(error) });
    } finally {
      setLoadingGoogle(false);
    }
  }

  return (
    <section className="section-shell pb-14 pt-8 sm:pb-20">
      <div className="grid gap-8 lg:grid-cols-[1fr_0.95fr] lg:items-center">
        <div className="max-w-2xl">
          <span className="eyebrow">Secure access layer</span>
          <h1 className="mt-6 font-[var(--font-jakarta)] text-4xl font-semibold tracking-tight text-white sm:text-5xl">
            {copy.heading}
          </h1>
          <p className="mt-5 max-w-xl text-lg leading-8 text-muted">{copy.paragraph}</p>
          <div className="mt-8 grid gap-4 sm:grid-cols-3">
            {[
              'Google OAuth real',
              'OTP nomor telepon',
              'Dashboard protected'
            ].map((item) => (
              <div key={item} className="rounded-3xl border border-white/10 bg-white/5 px-4 py-4 text-sm text-white/72 backdrop-blur-xl">
                {item}
              </div>
            ))}
          </div>
        </div>

        <div className="surface relative overflow-hidden px-5 py-6 sm:px-7 sm:py-8">
          <div className="absolute inset-0 bg-[linear-gradient(145deg,rgba(124,230,255,0.08),transparent_40%,rgba(159,124,255,0.10)_100%)]" />
          <div className="relative z-10">
            <div className="mb-6 flex items-center justify-between gap-4">
              <div>
                <p className="text-sm text-white/48">{isRegister ? 'Registrasi' : 'Login'}</p>
                <h2 className="mt-1 font-[var(--font-jakarta)] text-2xl font-semibold text-white">
                  {isRegister ? 'Akses baru' : 'Akses aman'}
                </h2>
              </div>
              <ButtonLink href="/layanan" variant="ghost" size="sm">
                Lihat Layanan
              </ButtonLink>
            </div>

            <div className="space-y-4">
              <GoogleAuthButton label={copy.googleLabel} onClick={handleGoogleAuth} loading={loadingGoogle || finalizing} />

              <div className="relative py-2 text-center text-xs uppercase tracking-[0.22em] text-white/35">
                <span className="relative z-10 bg-transparent px-3">atau</span>
                <div className="absolute left-0 top-1/2 h-px w-full -translate-y-1/2 bg-white/8" />
              </div>

              <PhoneAuthForm mode={mode} onAuthenticated={finalizeAuth} />

              {status ? <StatusBox type={status.type} message={status.message} /> : null}
            </div>

            <p className="mt-6 text-sm text-white/60">
              {copy.switchText}{' '}
              <Link className="text-accent-cyan transition hover:text-white" href={copy.switchHref}>
                {copy.switchLabel}
              </Link>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
