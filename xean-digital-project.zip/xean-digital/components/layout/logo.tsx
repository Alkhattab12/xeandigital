import Link from 'next/link';

import { cn } from '@/lib/utils';

export function Logo({ className }: { className?: string }) {
  return (
    <Link className={cn('inline-flex items-center gap-3', className)} href="/">
      <div className="relative flex h-11 w-11 items-center justify-center rounded-2xl border border-white/12 bg-white/6 shadow-[0_12px_38px_rgba(53,109,247,0.18)] backdrop-blur-xl">
        <div className="absolute inset-0 rounded-2xl bg-[radial-gradient(circle_at_30%_20%,rgba(124,230,255,0.35),transparent_38%),radial-gradient(circle_at_75%_75%,rgba(159,124,255,0.35),transparent_42%)]" />
        <span className="relative font-[var(--font-jakarta)] text-lg font-semibold tracking-tight text-white">X</span>
      </div>
      <div className="leading-tight">
        <div className="font-[var(--font-jakarta)] text-sm font-semibold tracking-[0.22em] text-white/90">XEAN</div>
        <div className="text-xs uppercase tracking-[0.32em] text-white/45">Digital</div>
      </div>
    </Link>
  );
}
