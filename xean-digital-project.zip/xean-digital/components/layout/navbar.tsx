'use client';

import Link from 'next/link';
import { Menu, X } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import { useState } from 'react';
import { usePathname } from 'next/navigation';

import { ButtonLink } from '@/components/ui/button';
import { Logo } from '@/components/layout/logo';
import { useAuth } from '@/components/providers/auth-provider';
import { siteConfig } from '@/lib/config/site';
import { cn } from '@/lib/utils';

export function Navbar() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const { user } = useAuth();

  const links = user
    ? [...siteConfig.nav.slice(0, 3), { label: 'Dashboard', href: '/dashboard' }]
    : siteConfig.nav;

  return (
    <header className="fixed inset-x-0 top-0 z-50">
      <div className="section-shell pt-4">
        <div className="surface flex items-center justify-between px-4 py-3 sm:px-5">
          <Logo />

          <nav className="hidden items-center gap-2 lg:flex">
            {links.map((item) => {
              const active = pathname === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    'rounded-full px-4 py-2 text-sm text-white/68 transition hover:text-white',
                    active && 'bg-white/8 text-white'
                  )}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="hidden items-center gap-3 lg:flex">
            <ButtonLink href={user ? '/dashboard' : '/daftar'} size="sm">
              {user ? 'Buka Dashboard' : 'Daftar Sekarang'}
            </ButtonLink>
          </div>

          <button
            className="inline-flex h-11 w-11 items-center justify-center rounded-2xl border border-white/10 bg-white/6 text-white lg:hidden"
            onClick={() => setOpen((value) => !value)}
            aria-label="Toggle navigation"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open ? (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="section-shell pt-3 lg:hidden"
          >
            <div className="surface space-y-2 px-4 py-4">
              {links.map((item) => {
                const active = pathname === item.href;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={cn(
                      'block rounded-2xl px-4 py-3 text-sm text-white/72 transition hover:bg-white/6 hover:text-white',
                      active && 'bg-white/8 text-white'
                    )}
                    onClick={() => setOpen(false)}
                  >
                    {item.label}
                  </Link>
                );
              })}
              <ButtonLink className="w-full" href={user ? '/dashboard' : '/daftar'} size="sm">
                {user ? 'Masuk Dashboard' : 'Mulai Sekarang'}
              </ButtonLink>
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </header>
  );
}
