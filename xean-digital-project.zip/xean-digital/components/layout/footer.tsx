import Link from 'next/link';

import { Container } from '@/components/ui/container';
import { Logo } from '@/components/layout/logo';
import { siteConfig } from '@/lib/config/site';

export function Footer() {
  return (
    <footer className="border-t border-white/8 py-10">
      <Container>
        <div className="surface grid gap-8 px-6 py-8 lg:grid-cols-[1.2fr_0.9fr_0.9fr] lg:px-8">
          <div>
            <Logo />
            <p className="mt-4 max-w-md text-sm leading-7 text-muted">{siteConfig.description}</p>
          </div>

          <div>
            <p className="font-[var(--font-jakarta)] text-sm font-semibold text-white">Navigasi</p>
            <div className="mt-4 flex flex-col gap-3 text-sm text-white/70">
              {siteConfig.nav.map((item) => (
                <Link key={item.href} href={item.href} className="transition hover:text-white">
                  {item.label}
                </Link>
              ))}
            </div>
          </div>

          <div>
            <p className="font-[var(--font-jakarta)] text-sm font-semibold text-white">Kontak & Operasional</p>
            <div className="mt-4 space-y-3 text-sm text-white/70">
              <p>Domain utama: {siteConfig.domain}</p>
              <p>Email: {siteConfig.contactEmail}</p>
              <p>WhatsApp: +{siteConfig.whatsappNumber}</p>
            </div>
          </div>
        </div>
        <div className="mt-4 flex flex-col gap-2 px-1 text-xs text-white/45 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} Xean Digital. Crafted for modern digital growth.</p>
          <p>Premium aesthetic. Real authentication. Multi-page architecture.</p>
        </div>
      </Container>
    </footer>
  );
}
