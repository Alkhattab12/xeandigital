import { Star } from 'lucide-react';

import { Container } from '@/components/ui/container';
import { Reveal } from '@/components/ui/reveal';
import { SectionHeading } from '@/components/ui/section-heading';
import { socialProof } from '@/lib/data/services';

const testimonials = [
  {
    name: 'Rafi, Founder Brand Tools',
    quote:
      'Tampilan websitenya terasa premium, tapi yang paling saya suka adalah alurnya tetap jelas untuk user. Tidak hanya estetik, tapi juga bekerja.'
  },
  {
    name: 'Nadya, Digital Seller',
    quote:
      'Prosesnya rapi, cepat, dan komunikatif. Untuk layanan bot dan panel, semuanya dijelaskan dengan jelas tanpa bikin bingung.'
  },
  {
    name: 'Aldo, Growth Operator',
    quote:
      'Xean Digital paham bagaimana membuat brand terlihat modern tanpa kehilangan rasa percaya. Itu terasa dari desain dan struktur halamannya.'
  }
];

export function TestimonialsSection() {
  return (
    <section className="py-14 sm:py-20">
      <Container>
        <Reveal>
          <SectionHeading
            eyebrow="Social proof"
            title="Kesan yang dibangun bukan sekadar visual"
            description="Brand digital yang baik membuat orang langsung paham, percaya, lalu bergerak. Itulah impresi yang ingin dibawa Xean Digital."
          />
        </Reveal>

        <div className="mt-8 grid gap-4 lg:grid-cols-3">
          {socialProof.map((item, index) => (
            <Reveal key={item} delay={index * 0.05}>
              <div className="rounded-3xl border border-white/10 bg-white/5 px-5 py-4 text-sm text-white/78 backdrop-blur-xl">
                {item}
              </div>
            </Reveal>
          ))}
        </div>

        <div className="mt-8 grid gap-5 lg:grid-cols-3">
          {testimonials.map((item, index) => (
            <Reveal key={item.name} delay={0.08 + index * 0.06}>
              <div className="glass-hover h-full rounded-[28px] border border-white/10 bg-white/5 p-6 backdrop-blur-xl">
                <div className="flex gap-1 text-amber-300">
                  {Array.from({ length: 5 }).map((_, starIndex) => (
                    <Star key={starIndex} className="h-4 w-4 fill-current" />
                  ))}
                </div>
                <p className="mt-5 text-base leading-8 text-white/82">“{item.quote}”</p>
                <p className="mt-6 text-sm font-medium text-white">{item.name}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
