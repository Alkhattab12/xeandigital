'use client';

import { ArrowRight, Sparkles } from 'lucide-react';
import { motion, useMotionTemplate, useMotionValue } from 'framer-motion';
import { useMemo } from 'react';

import { ButtonLink } from '@/components/ui/button';
import { Container } from '@/components/ui/container';

const points = [
  'Website premium multi-halaman',
  'Bot WhatsApp & automasi',
  'Panel & katalog layanan digital'
];

export function HeroSection() {
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  const spotlight = useMotionTemplate`radial-gradient(420px circle at ${mouseX}px ${mouseY}px, rgba(124,230,255,0.16), transparent 55%)`;

  const floatingNodes = useMemo(
    () => [
      'Strategic digital build',
      'Motion-forward interface',
      'Auth & dashboard ready'
    ],
    []
  );

  return (
    <section className="relative overflow-hidden pb-14 pt-8 sm:pb-24 sm:pt-10">
      <motion.div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-90"
        style={{ backgroundImage: spotlight }}
        onMouseMove={() => undefined}
      />
      <Container>
        <div
          className="grid gap-10 lg:grid-cols-[1.1fr_0.9fr] lg:items-center"
          onMouseMove={(event) => {
            const rect = event.currentTarget.getBoundingClientRect();
            mouseX.set(event.clientX - rect.left);
            mouseY.set(event.clientY - rect.top);
          }}
        >
          <div>
            <span className="eyebrow">
              <Sparkles className="h-3.5 w-3.5" /> Brand digital premium untuk sistem modern
            </span>
            <motion.h1
              className="mt-6 max-w-4xl font-[var(--font-jakarta)] text-5xl font-semibold tracking-tight text-white sm:text-6xl lg:text-7xl"
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
            >
              Xean Digital merancang <span className="headline-gradient">pengalaman digital</span> yang terasa mahal, bergerak halus, dan siap dipakai.
            </motion.h1>
            <motion.p
              className="mt-6 max-w-2xl text-lg leading-8 text-muted sm:text-xl"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.75, delay: 0.12, ease: [0.22, 1, 0.36, 1] }}
            >
              Dari website premium hingga bot WhatsApp, panel, dan automasi operasional—kami membantu brand tampil lebih cerdas, dipercaya lebih cepat, dan tumbuh dengan sistem yang lebih rapi.
            </motion.p>
            <motion.div
              className="mt-8 flex flex-col gap-4 sm:flex-row"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.75, delay: 0.22 }}
            >
              <ButtonLink href="/daftar" size="lg">
                Daftar Sekarang <ArrowRight className="h-4 w-4" />
              </ButtonLink>
              <ButtonLink href="/tentang-kami" variant="secondary" size="lg">
                Pelajari Lebih Lanjut
              </ButtonLink>
            </motion.div>
            <div className="mt-10 flex flex-wrap gap-3">
              {points.map((point) => (
                <span
                  key={point}
                  className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-white/72 backdrop-blur"
                >
                  {point}
                </span>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="absolute inset-0 blur-3xl">
              <div className="absolute right-8 top-4 h-28 w-28 rounded-full bg-accent-cyan/20" />
              <div className="absolute bottom-12 left-10 h-32 w-32 rounded-full bg-accent-purple/20" />
            </div>
            <div className="surface relative overflow-hidden p-6 sm:p-7">
              <div className="absolute inset-0 bg-[linear-gradient(135deg,rgba(124,230,255,0.12),transparent_40%,rgba(159,124,255,0.14)_85%)]" />
              <div className="relative z-10">
                <div className="mb-6 flex items-center justify-between">
                  <div>
                    <p className="text-sm text-white/55">Preview identitas sistem</p>
                    <p className="mt-1 font-[var(--font-jakarta)] text-xl font-semibold text-white">Xean Control Surface</p>
                  </div>
                  <div className="rounded-full border border-emerald-400/20 bg-emerald-400/8 px-3 py-1 text-xs text-emerald-200">
                    Live-ready
                  </div>
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                  {floatingNodes.map((node, index) => (
                    <motion.div
                      key={node}
                      className="glass-hover rounded-3xl border border-white/10 bg-white/5 p-4 backdrop-blur-xl"
                      animate={{ y: [0, -8, 0] }}
                      transition={{ duration: 6 + index, repeat: Infinity, ease: 'easeInOut' }}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs uppercase tracking-[0.2em] text-white/45">Layer {index + 1}</span>
                        <span className="h-2.5 w-2.5 rounded-full bg-accent-cyan/90 shadow-[0_0_22px_rgba(124,230,255,0.7)]" />
                      </div>
                      <p className="mt-4 font-[var(--font-jakarta)] text-lg font-medium text-white">{node}</p>
                      <p className="mt-2 text-sm leading-6 text-muted">Presisi visual dan sistem nyata berjalan beriringan, bukan hanya kemasan.</p>
                    </motion.div>
                  ))}
                </div>

                <div className="mt-5 rounded-3xl border border-white/10 bg-black/20 p-5">
                  <div className="flex items-center justify-between text-xs uppercase tracking-[0.2em] text-white/45">
                    <span>Trust signal</span>
                    <span>Realtime impression</span>
                  </div>
                  <div className="mt-4 grid grid-cols-3 gap-3">
                    <div>
                      <p className="font-[var(--font-jakarta)] text-2xl font-semibold text-white">24/7</p>
                      <p className="mt-1 text-sm text-muted">Digital readiness</p>
                    </div>
                    <div>
                      <p className="font-[var(--font-jakarta)] text-2xl font-semibold text-white">Multi</p>
                      <p className="mt-1 text-sm text-muted">Halaman utama</p>
                    </div>
                    <div>
                      <p className="font-[var(--font-jakarta)] text-2xl font-semibold text-white">Real</p>
                      <p className="mt-1 text-sm text-muted">Firebase auth</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </section>
  );
}
