import Link from 'next/link';
import { ArrowUpRight } from 'lucide-react';

import { Container } from '@/components/ui/container';
import { Reveal } from '@/components/ui/reveal';
import { SectionHeading } from '@/components/ui/section-heading';
import { serviceCatalogLinks } from '@/lib/data/services';

export function ServicePreviewSection() {
  const featured = serviceCatalogLinks.slice(0, 4);

  return (
    <section className="py-14 sm:py-20">
      <Container>
        <Reveal>
          <SectionHeading
            eyebrow="Layanan inti"
            title="Dirancang untuk kebutuhan digital yang bergerak cepat"
            description="Xean Digital memadukan desain, sistem, dan automasi supaya brand tidak hanya terlihat bagus, tetapi juga lebih siap digunakan dan lebih mudah berkembang."
          />
        </Reveal>

        <div className="mt-10 grid gap-5 lg:grid-cols-2 xl:grid-cols-4">
          {featured.map((service, index) => (
            <Reveal key={service.slug} delay={index * 0.06}>
              <div className="glass-hover h-full rounded-[28px] border border-white/10 bg-white/5 p-5 backdrop-blur-xl">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <span className="text-xs uppercase tracking-[0.22em] text-white/45">{service.category}</span>
                    <h3 className="mt-3 font-[var(--font-jakarta)] text-xl font-semibold text-white">{service.title}</h3>
                  </div>
                  <ArrowUpRight className="mt-1 h-5 w-5 text-accent-cyan" />
                </div>
                <p className="mt-3 text-sm leading-7 text-muted">{service.short}</p>
                <p className="mt-5 text-sm font-medium text-white/80">{service.price}</p>
                <Link href="/layanan" className="mt-6 inline-flex items-center gap-2 text-sm text-white transition hover:text-accent-cyan">
                  Lihat detail katalog <ArrowUpRight className="h-4 w-4" />
                </Link>
              </div>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
