import { AlertCircle, CheckCircle2, Info } from 'lucide-react';

import { cn } from '@/lib/utils';

const icons = {
  error: AlertCircle,
  success: CheckCircle2,
  info: Info
};

export function StatusBox({
  type,
  message,
  className
}: {
  type: keyof typeof icons;
  message: string;
  className?: string;
}) {
  const Icon = icons[type];

  return (
    <div
      className={cn(
        'flex items-start gap-3 rounded-2xl border px-4 py-3 text-sm',
        type === 'error' && 'border-rose-400/20 bg-rose-400/8 text-rose-100',
        type === 'success' && 'border-emerald-400/20 bg-emerald-400/8 text-emerald-100',
        type === 'info' && 'border-accent-cyan/20 bg-accent-cyan/8 text-cyan-50',
        className
      )}
    >
      <Icon className="mt-0.5 h-4 w-4 shrink-0" />
      <p>{message}</p>
    </div>
  );
}
