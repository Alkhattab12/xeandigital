import type { ReactNode } from 'react';
import Link from 'next/link';
import { LoaderCircle } from 'lucide-react';
import * as React from 'react';

import { cn } from '@/lib/utils';

type BaseProps = {
  variant?: 'primary' | 'secondary' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  className?: string;
  children: ReactNode;
};

type ButtonProps = BaseProps & React.ButtonHTMLAttributes<HTMLButtonElement>;
type LinkProps = BaseProps & React.AnchorHTMLAttributes<HTMLAnchorElement> & { href: string };

const styles = {
  base: 'group relative inline-flex items-center justify-center overflow-hidden rounded-full font-medium transition-all duration-300 focus:outline-none focus-visible:ring-2 focus-visible:ring-accent-cyan/70 disabled:pointer-events-none disabled:opacity-60',
  variant: {
    primary:
      'bg-white text-slate-950 shadow-glow hover:scale-[1.01] hover:shadow-[0_20px_70px_rgba(124,230,255,0.22)]',
    secondary:
      'border border-white/12 bg-white/6 text-white backdrop-blur-xl hover:border-accent-cyan/35 hover:bg-white/10',
    ghost: 'text-white/80 hover:bg-white/6 hover:text-white'
  },
  size: {
    sm: 'h-10 px-4 text-sm',
    md: 'h-12 px-6 text-sm sm:text-base',
    lg: 'h-14 px-7 text-base'
  }
};

export function Button({ variant = 'primary', size = 'md', loading, className, children, ...props }: ButtonProps) {
  return (
    <button className={cn(styles.base, styles.variant[variant], styles.size[size], className)} {...props}>
      <span className="absolute inset-0 -translate-x-[120%] bg-gradient-to-r from-transparent via-white/30 to-transparent opacity-0 transition-opacity duration-300 group-hover:animate-shine group-hover:opacity-100" />
      <span className="relative z-10 inline-flex items-center gap-2">
        {loading ? <LoaderCircle className="h-4 w-4 animate-spin" /> : null}
        {children}
      </span>
    </button>
  );
}

export function ButtonLink({ variant = 'primary', size = 'md', loading, className, children, href, ...props }: LinkProps) {
  return (
    <Link className={cn(styles.base, styles.variant[variant], styles.size[size], className)} href={href} {...props}>
      <span className="absolute inset-0 -translate-x-[120%] bg-gradient-to-r from-transparent via-white/30 to-transparent opacity-0 transition-opacity duration-300 group-hover:animate-shine group-hover:opacity-100" />
      <span className="relative z-10 inline-flex items-center gap-2">
        {loading ? <LoaderCircle className="h-4 w-4 animate-spin" /> : null}
        {children}
      </span>
    </Link>
  );
}
