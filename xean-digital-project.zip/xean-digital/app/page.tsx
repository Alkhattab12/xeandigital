import { ArrowRight, ShieldCheck, Sparkles, Workflow } from 'lucide-react';

import { HeroSection } from '@/components/sections/hero';
import { ServicePreviewSection } from '@/components/sections/service-preview';
import { TestimonialsSection } from '@/components/sections/testimonials';
import { ButtonLink } from '@/components/ui/button';
import { Container } from '@/components/ui/container';
import { Reveal } from '@/components/ui/reveal';
import { SectionHeading } from '@/components/ui/section-heading';

const strengths = [
  {
    icon: Sparkles,
    title: 'Brand presence yang terasa premium',
    description: 'Visual yang abstrak, clean, dan elegan untuk membangun kesan modern tanpa kehilangan kredibilitas.'
  },
  {
    icon: Workflow,
    title: 'Sistem yang tidak berhenti di estetika',
    description: 'Struktur multi-halaman, CTA jelas, katalog layanan rapi, dan alur autentikasi nyata siap digunakan.'
  },
  {
    icon: ShieldCheck,
    title: 'Terlihat modern, tetap terasa aman',
    description: 'Google OAuth dan login nomor telepon via OTP dengan session protection untuk akses dashboard.'
  }
];

export default function HomePage() {
  return (
    <>
      <HeroSection />

      <section className="pb-14 sm:pb-20">
        <Container>
          <Reveal>
            <div className="surface grid gap-6 px-6 py-8 lg:grid-cols-[1fr_0.95fr] lg:px-8 lg:py-10">
              <div>
                <span className="eyebrow">Apa itu Xean Digital?</span>
                <h2 className="mt-5 font-[var(--font-jakarta)] text-3xl font-semibold tracking-tight text-white sm:text-4xl">
                  Xean Digital adalah partner creative-tech untuk brand yang ingin tampil lebih serius di ranah digital.
                </h2>
              </div>
              <div>
                <p className="text-base leading-8 text-muted sm:text-lg">
                  Kami menggabungkan desain premium, struktur website yang rapi, layanan digital yang relevan, serta sistem autentikasi dan dashboard yang benar-benar berfungsi. Tujuannya sederhana: membuat brand Anda terasa lebih matang, lebih dipercaya, dan lebih siap berkembang.
                </p>
                <div className="mt-6 flex flex-col gap-4 sm:flex-row">
                  <ButtonLink href="/daftar">
                    Mulai Sekarang <ArrowRight className="h-4 w-4" />
                  </ButtonLink>
                  <ButtonLink href="/tentang-kami" variant="secondary">
                    Kenali Brand
                  </ButtonLink>
                </div>
              </div>
            </div>
          </Reveal>
        </Container>
      </section>

      <section className="py-14 sm:py-20">
        <Container>
          <Reveal>
            <SectionHeading
              eyebrow="Keunggulan utama"
              title="Dibangun untuk terasa kreatif, namun tetap mudah dipercaya"
              description="Website ini tidak diposisikan sebagai landing panjang biasa. Struktur dipisah jelas agar brand terasa lebih dewasa, lebih fokus, dan lebih profesional saat dikunjungi user."
            />
          </Reveal>

          <div className="mt-10 grid gap-5 lg:grid-cols-3">
            {strengths.map((item, index) => {
              const Icon = item.icon;
              return (
                <Reveal key={item.title} delay={index * 0.07}>
                  <div className="glass-hover h-full rounded-[30px] border border-white/10 bg-white/5 p-6 backdrop-blur-xl">
                    <div className="inline-flex rounded-2xl border border-white/10 bg-white/5 p-3 text-accent-cyan">
                      <Icon className="h-6 w-6" />
                    </div>
                    <h3 className="mt-5 font-[var(--font-jakarta)] text-xl font-semibold text-white">{item.title}</h3>
                    <p className="mt-3 text-sm leading-7 text-muted">{item.description}</p>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </Container>
      </section>

      <ServicePreviewSection />
      <TestimonialsSection />

      <section className="pb-16 pt-8 sm:pb-24">
        <Container>
          <Reveal>
            <div className="surface relative overflow-hidden px-6 py-8 sm:px-8 sm:py-10">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_10%_10%,rgba(124,230,255,0.14),transparent_30%),radial-gradient(circle_at_90%_0%,rgba(159,124,255,0.18),transparent_34%)]" />
              <div className="relative z-10 flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
                <div className="max-w-2xl">
                  <span className="eyebrow">Arahkan user ke aksi</span>
                  <h2 className="mt-5 font-[var(--font-jakarta)] text-3xl font-semibold tracking-tight text-white sm:text-4xl">
                    Saat brand Anda sudah siap, user juga harus tahu ke mana harus melangkah.
                  </h2>
                  <p className="mt-4 text-base leading-8 text-muted sm:text-lg">
                    Gunakan alur pendaftaran dan login untuk mulai membangun ekosistem Xean Digital—lebih tertata, lebih modern, dan lebih meyakinkan sejak kunjungan pertama.
                  </p>
                </div>
                <div className="flex flex-col gap-4 sm:flex-row">
                  <ButtonLink href="/daftar" size="lg">
                    Daftar Sekarang
                  </ButtonLink>
                  <ButtonLink href="/layanan" variant="secondary" size="lg">
                    Lihat Katalog
                  </ButtonLink>
                </div>
              </div>
            </div>
          </Reveal>
        </Container>
      </section>
    </>
  );
}
