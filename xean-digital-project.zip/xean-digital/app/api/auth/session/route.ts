import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';

import { SESSION_COOKIE_NAME } from '@/lib/auth/session';
import { adminAuth, adminDb } from '@/lib/firebase/admin';

const EXPIRES_IN = 60 * 60 * 24 * 5 * 1000;

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as { idToken?: string };
    const idToken = body.idToken;

    if (!idToken) {
      return NextResponse.json({ message: 'ID token tidak ditemukan.' }, { status: 400 });
    }

    const decoded = await adminAuth().verifyIdToken(idToken);
    const sessionCookie = await adminAuth().createSessionCookie(idToken, { expiresIn: EXPIRES_IN });
    const userRecord = await adminAuth().getUser(decoded.uid);

    try {
      await adminDb()
        .collection('users')
        .doc(decoded.uid)
        .set(
          {
            uid: decoded.uid,
            displayName: userRecord.displayName || decoded.name || null,
            email: userRecord.email || decoded.email || null,
            phoneNumber: userRecord.phoneNumber || decoded.phone_number || null,
            photoURL: userRecord.photoURL || null,
            providers: userRecord.providerData.map((provider) => provider.providerId),
            createdAt: userRecord.metadata.creationTime || null,
            lastLoginAt: new Date().toISOString()
          },
          { merge: true }
        );
    } catch {
      // Firestore sync bersifat opsional agar login tetap berjalan walau database belum diinisialisasi.
    }

    const cookieStore = await cookies();
    cookieStore.set(SESSION_COOKIE_NAME, sessionCookie, {
      maxAge: EXPIRES_IN / 1000,
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/'
    });

    return NextResponse.json({ ok: true });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Gagal membuat sesi.';
    return NextResponse.json({ message }, { status: 500 });
  }
}

export async function DELETE() {
  const cookieStore = await cookies();
  cookieStore.set(SESSION_COOKIE_NAME, '', {
    maxAge: 0,
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/'
  });

  return NextResponse.json({ ok: true });
}
