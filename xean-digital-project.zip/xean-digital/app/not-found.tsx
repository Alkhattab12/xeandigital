import { ButtonLink } from '@/components/ui/button';
import { Container } from '@/components/ui/container';

export default function NotFound() {
  return (
    <section className="section-shell pb-16 pt-10 sm:pb-24">
      <Container className="px-0">
        <div className="surface flex flex-col items-start gap-5 px-6 py-10 sm:px-8">
          <span className="eyebrow">404</span>
          <h1 className="font-[var(--font-jakarta)] text-4xl font-semibold text-white">Halaman tidak ditemukan</h1>
          <p className="max-w-2xl text-base leading-8 text-muted">
            Route yang Anda cari tidak tersedia. Kembali ke home atau lihat katalog layanan Xean Digital.
          </p>
          <div className="flex flex-col gap-4 sm:flex-row">
            <ButtonLink href="/">Kembali ke Home</ButtonLink>
            <ButtonLink href="/layanan" variant="secondary">
              Lihat Layanan
            </ButtonLink>
          </div>
        </div>
      </Container>
    </section>
  );
}
