import type { Metadata } from 'next';

import { AuthPage } from '@/components/auth/auth-page';

export const metadata: Metadata = {
  title: 'Login',
  description: 'Login ke Xean Digital menggunakan Google OAuth atau OTP nomor telepon.'
};

export default function LoginPage() {
  return <AuthPage mode="login" />;
}
