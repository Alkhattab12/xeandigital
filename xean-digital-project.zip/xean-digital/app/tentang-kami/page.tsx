import type { Metadata } from 'next';
import { CheckCircle2, Compass, Gem, Layers3 } from 'lucide-react';

import { ButtonLink } from '@/components/ui/button';
import { Container } from '@/components/ui/container';
import { Reveal } from '@/components/ui/reveal';
import { SectionHeading } from '@/components/ui/section-heading';

export const metadata: Metadata = {
  title: 'Tentang Kami',
  description: 'Mengenal visi, misi, pendekatan, dan identitas brand Xean Digital.'
};

const pillars = [
  {
    icon: Compass,
    title: 'Visi',
    description: 'Membantu brand dan pelaku digital tampil lebih cerdas, rapi, dan bernilai tinggi melalui sistem digital yang terasa premium.'
  },
  {
    icon: Layers3,
    title: 'Misi',
    description: 'Menyediakan website, automasi, panel, bot, dan pengalaman digital yang bukan hanya enak dilihat, tetapi juga nyata dipakai.'
  },
  {
    icon: Gem,
    title: 'Identitas Brand',
    description: 'Modern, kreatif, terukur, dan tetap profesional. Xean Digital tidak mengejar “ramai”, tetapi mengejar kualitas impresi dan ketepatan eksekusi.'
  }
];

const reasons = [
  'Struktur website dipisah jelas, bukan one-page biasa yang cepat terasa generik.',
  'Desain abstrak dan futuristik tetap dijaga agar mudah dipahami user akhir.',
  'Pendekatan kami mengutamakan kesan premium sekaligus kejelasan alur bisnis.',
  'Solusi digital dikurasi untuk kebutuhan nyata: website, bot, panel, dan automasi.'
];

export default function AboutPage() {
  return (
    <section className="section-shell pb-16 pt-8 sm:pb-24">
      <Reveal>
        <SectionHeading
          eyebrow="Tentang Xean Digital"
          title="Creative tech brand yang merapikan cara brand hadir di dunia digital"
          description="Xean Digital lahir dari gagasan bahwa website, layanan, dan sistem tidak seharusnya terasa biasa. Mereka harus membentuk citra, mempermudah interaksi, dan membawa rasa percaya sejak awal."
        />
      </Reveal>

      <div className="mt-10 grid gap-5 lg:grid-cols-3">
        {pillars.map((item, index) => {
          const Icon = item.icon;
          return (
            <Reveal key={item.title} delay={index * 0.06}>
              <div className="glass-hover h-full rounded-[30px] border border-white/10 bg-white/5 p-6 backdrop-blur-xl">
                <div className="inline-flex rounded-2xl border border-white/10 bg-white/5 p-3 text-accent-cyan">
                  <Icon className="h-6 w-6" />
                </div>
                <h2 className="mt-5 font-[var(--font-jakarta)] text-xl font-semibold text-white">{item.title}</h2>
                <p className="mt-3 text-sm leading-7 text-muted">{item.description}</p>
              </div>
            </Reveal>
          );
        })}
      </div>

      <div className="mt-10 grid gap-6 lg:grid-cols-[1fr_1fr]">
        <Reveal>
          <div className="surface h-full px-6 py-7 sm:px-8">
            <h3 className="font-[var(--font-jakarta)] text-2xl font-semibold text-white">Pendekatan kerja kami</h3>
            <p className="mt-4 text-base leading-8 text-muted">
              Kami melihat website dan sistem sebagai bagian dari persepsi brand. Karena itu, kami merancang pengalaman digital dengan pendekatan yang seimbang: visual yang elegan, alur yang jelas, CTA yang kuat, dan teknologi yang siap dipakai secara nyata.
            </p>
            <p className="mt-4 text-base leading-8 text-muted">
              Xean Digital tidak hanya membangun halaman, tetapi membangun struktur kehadiran digital—supaya bisnis lebih mudah dipahami, lebih meyakinkan, dan lebih siap dikembangkan ke tahap berikutnya.
            </p>
          </div>
        </Reveal>

        <Reveal delay={0.08}>
          <div className="surface h-full px-6 py-7 sm:px-8">
            <h3 className="font-[var(--font-jakarta)] text-2xl font-semibold text-white">Kenapa memilih Xean Digital</h3>
            <div className="mt-5 space-y-4">
              {reasons.map((reason) => (
                <div key={reason} className="flex items-start gap-3 rounded-2xl border border-white/8 bg-white/4 px-4 py-4">
                  <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-accent-cyan" />
                  <p className="text-sm leading-7 text-white/78">{reason}</p>
                </div>
              ))}
            </div>
          </div>
        </Reveal>
      </div>

      <Container className="mt-10 px-0">
        <Reveal>
          <div className="surface flex flex-col gap-5 px-6 py-8 sm:px-8 lg:flex-row lg:items-center lg:justify-between">
            <div className="max-w-2xl">
              <h3 className="font-[var(--font-jakarta)] text-2xl font-semibold text-white">Siap mulai membangun presence digital yang lebih serius?</h3>
              <p className="mt-3 text-base leading-8 text-muted">
                Lihat katalog layanan atau buat akses ke dashboard Anda untuk memulai alur berikutnya.
              </p>
            </div>
            <div className="flex flex-col gap-4 sm:flex-row">
              <ButtonLink href="/layanan">Lihat Layanan</ButtonLink>
              <ButtonLink href="/daftar" variant="secondary">
                Daftar Sekarang
              </ButtonLink>
            </div>
          </div>
        </Reveal>
      </Container>
    </section>
  );
}
