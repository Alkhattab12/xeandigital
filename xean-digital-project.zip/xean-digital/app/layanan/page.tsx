import type { Metadata } from 'next';
import Link from 'next/link';
import { ArrowUpRight, BadgeCheck } from 'lucide-react';

import { ButtonLink } from '@/components/ui/button';
import { Container } from '@/components/ui/container';
import { Reveal } from '@/components/ui/reveal';
import { SectionHeading } from '@/components/ui/section-heading';
import { serviceCatalogLinks } from '@/lib/data/services';

export const metadata: Metadata = {
  title: 'Layanan',
  description: 'Katalog layanan digital dari Xean Digital: website, panel, social media injection, bot WhatsApp, desain, dan automasi.'
};

export default function ServicesPage() {
  return (
    <section className="section-shell pb-16 pt-8 sm:pb-24">
      <Reveal>
        <SectionHeading
          eyebrow="Katalog layanan"
          title="Semua layanan Xean Digital dirancang agar brand terlihat lebih siap, bukan sekadar lebih ramai"
          description="Pilih layanan yang sesuai dengan kebutuhan Anda. Setiap kartu di bawah ini sudah dilengkapi CTA langsung ke WhatsApp dengan pesan custom sesuai pilihan layanan."
        />
      </Reveal>

      <div className="mt-10 grid gap-5 lg:grid-cols-2 xl:grid-cols-3">
        {serviceCatalogLinks.map((service, index) => (
          <Reveal key={service.slug} delay={index * 0.05}>
            <div className="glass-hover flex h-full flex-col rounded-[30px] border border-white/10 bg-white/5 p-6 backdrop-blur-xl">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <span className="text-xs uppercase tracking-[0.24em] text-white/45">{service.category}</span>
                  <h2 className="mt-3 font-[var(--font-jakarta)] text-2xl font-semibold text-white">{service.title}</h2>
                </div>
                <BadgeCheck className="h-5 w-5 text-accent-cyan" />
              </div>
              <p className="mt-4 text-sm leading-7 text-muted">{service.description}</p>

              <div className="mt-5 rounded-3xl border border-white/8 bg-black/20 p-4">
                <p className="text-sm font-medium text-white/80">{service.highlight}</p>
                <p className="mt-2 text-sm text-accent-cyan">{service.price}</p>
              </div>

              <div className="mt-5 space-y-3">
                {service.bullets.map((bullet) => (
                  <div key={bullet} className="flex items-center gap-3 text-sm text-white/75">
                    <span className="h-2 w-2 rounded-full bg-accent-cyan" />
                    <span>{bullet}</span>
                  </div>
                ))}
              </div>

              <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:flex-wrap">
                <Link
                  href={service.whatsappLink}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center justify-center gap-2 rounded-full bg-white px-5 py-3 text-sm font-medium text-slate-950 transition hover:scale-[1.01]"
                >
                  {service.ctaLabel} <ArrowUpRight className="h-4 w-4" />
                </Link>
                <ButtonLink href="/daftar" variant="secondary" size="md">
                  Buat Akses
                </ButtonLink>
              </div>
            </div>
          </Reveal>
        ))}
      </div>

      <div className="mt-10">
        <Reveal>
          <div className="surface flex flex-col gap-5 px-6 py-8 sm:px-8 lg:flex-row lg:items-center lg:justify-between">
            <div className="max-w-2xl">
              <h3 className="font-[var(--font-jakarta)] text-2xl font-semibold text-white">Butuh kombinasi beberapa layanan sekaligus?</h3>
              <p className="mt-3 text-base leading-8 text-muted">
                Xean Digital juga bisa menyiapkan paket yang lebih terintegrasi: website + bot + automasi + dashboard, disesuaikan dengan alur bisnis Anda.
              </p>
            </div>
            <div className="flex flex-col gap-4 sm:flex-row">
              <ButtonLink href="/daftar">Daftar Sekarang</ButtonLink>
              <ButtonLink href="/login" variant="secondary">
                Sudah Punya Akses
              </ButtonLink>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
