import type { Metadata } from 'next';

import { AuthPage } from '@/components/auth/auth-page';

export const metadata: Metadata = {
  title: 'Daftar',
  description: 'Daftar ke Xean Digital dengan Google atau nomor telepon via OTP.'
};

export default function RegisterPage() {
  return <AuthPage mode="register" />;
}
