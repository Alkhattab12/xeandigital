export default function DashboardLoading() {
  return (
    <div className="section-shell pb-16 pt-8 sm:pb-24">
      <div className="surface animate-pulse px-6 py-10 sm:px-8">
        <div className="h-4 w-40 rounded-full bg-white/10" />
        <div className="mt-5 h-8 w-72 rounded-full bg-white/10" />
        <div className="mt-4 h-4 w-full max-w-2xl rounded-full bg-white/10" />
      </div>
    </div>
  );
}
