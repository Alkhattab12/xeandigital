import type { Metadata } from 'next';
import { redirect } from 'next/navigation';
import { BarChart3, CreditCard, ShieldCheck, Sparkles } from 'lucide-react';

import { LogoutButton } from '@/components/auth/logout-button';
import { Container } from '@/components/ui/container';
import { getServerSession, getServerUserProfile } from '@/lib/auth/session';

export const metadata: Metadata = {
  title: 'Dashboard',
  description: 'Dashboard user setelah login ke Xean Digital.'
};

const dashboardCards = [
  {
    icon: Sparkles,
    title: 'Akses Anda aktif',
    description: 'Sesi login Anda sudah berjalan aman dan siap digunakan untuk interaksi berikutnya.'
  },
  {
    icon: BarChart3,
    title: 'Ruang untuk ekspansi',
    description: 'Dashboard ini disiapkan sebagai pondasi untuk katalog order, histori layanan, dan progress project.'
  },
  {
    icon: CreditCard,
    title: 'Siap dikembangkan',
    description: 'Flow ini sudah cukup bersih untuk dilanjutkan ke sistem invoice, order, atau membership digital.'
  }
];

export default async function DashboardPage() {
  const session = await getServerSession();

  if (!session) {
    redirect('/login');
  }

  const profile = await getServerUserProfile(session.uid);

  const displayName = (profile?.displayName as string | undefined) || session.name || 'User Xean Digital';
  const email = (profile?.email as string | undefined) || session.email || null;
  const phoneNumber = (profile?.phoneNumber as string | undefined) || session.phone_number || null;

  return (
    <section className="section-shell pb-16 pt-8 sm:pb-24">
      <div className="surface overflow-hidden px-6 py-7 sm:px-8">
        <div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <span className="eyebrow">
              <ShieldCheck className="h-3.5 w-3.5" /> Dashboard protected
            </span>
            <h1 className="mt-5 font-[var(--font-jakarta)] text-3xl font-semibold tracking-tight text-white sm:text-4xl">
              Selamat datang, {displayName}
            </h1>
            <p className="mt-3 max-w-2xl text-base leading-8 text-muted">
              Anda berhasil masuk ke dashboard Xean Digital. Halaman ini hanya bisa diakses user yang memiliki sesi login valid.
            </p>
          </div>
          <LogoutButton />
        </div>
      </div>

      <Container className="mt-8 px-0">
        <div className="grid gap-5 lg:grid-cols-[0.85fr_1.15fr]">
          <div className="surface h-full px-6 py-7 sm:px-8">
            <h2 className="font-[var(--font-jakarta)] text-2xl font-semibold text-white">Identitas akun</h2>
            <div className="mt-6 space-y-4">
              <div className="rounded-3xl border border-white/8 bg-white/4 px-4 py-4">
                <p className="text-xs uppercase tracking-[0.22em] text-white/45">Nama</p>
                <p className="mt-2 text-base text-white">{displayName}</p>
              </div>
              <div className="rounded-3xl border border-white/8 bg-white/4 px-4 py-4">
                <p className="text-xs uppercase tracking-[0.22em] text-white/45">Email</p>
                <p className="mt-2 text-base text-white">{email ?? 'Belum tersedia'}</p>
              </div>
              <div className="rounded-3xl border border-white/8 bg-white/4 px-4 py-4">
                <p className="text-xs uppercase tracking-[0.22em] text-white/45">Nomor Telepon</p>
                <p className="mt-2 text-base text-white">{phoneNumber ?? 'Belum tersedia'}</p>
              </div>
            </div>
          </div>

          <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
            {dashboardCards.map((item) => {
              const Icon = item.icon;
              return (
                <div key={item.title} className="glass-hover rounded-[30px] border border-white/10 bg-white/5 p-6 backdrop-blur-xl">
                  <div className="inline-flex rounded-2xl border border-white/10 bg-white/5 p-3 text-accent-cyan">
                    <Icon className="h-6 w-6" />
                  </div>
                  <h3 className="mt-5 font-[var(--font-jakarta)] text-xl font-semibold text-white">{item.title}</h3>
                  <p className="mt-3 text-sm leading-7 text-muted">{item.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </Container>

      <Container className="mt-8 px-0">
        <div className="surface px-6 py-7 sm:px-8">
          <h2 className="font-[var(--font-jakarta)] text-2xl font-semibold text-white">Empty state yang bersih</h2>
          <p className="mt-3 max-w-3xl text-base leading-8 text-muted">
            Saat ini belum ada histori order atau aktivitas yang ditampilkan. Area ini sengaja disiapkan sebagai ruang pengembangan untuk order list, invoice, status project, atau membership digital berikutnya.
          </p>
        </div>
      </Container>
    </section>
  );
}
